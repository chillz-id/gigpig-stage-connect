-- Enable pgvector extension (should already be enabled)
CREATE EXTENSION IF NOT EXISTS vector;

-- Agent memories table with vector embeddings
CREATE TABLE IF NOT EXISTS agent_memories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id TEXT NOT NULL,
    content TEXT NOT NULL,
    embedding vector(1536), -- OpenAI embeddings dimension
    metadata JSONB DEFAULT '{}',
    memory_type TEXT NOT NULL CHECK (memory_type IN ('conversation', 'code', 'task', 'knowledge', 'decision')),
    importance FLOAT DEFAULT 0.5,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    accessed_at TIMESTAMPTZ DEFAULT NOW(),
    access_count INTEGER DEFAULT 0
);

-- Index for fast vector similarity search
CREATE INDEX IF NOT EXISTS agent_memories_embedding_idx ON agent_memories 
USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);

-- Index for filtering
CREATE INDEX IF NOT EXISTS agent_memories_agent_id_idx ON agent_memories(agent_id);
CREATE INDEX IF NOT EXISTS agent_memories_type_idx ON agent_memories(memory_type);
CREATE INDEX IF NOT EXISTS agent_memories_created_idx ON agent_memories(created_at DESC);

-- Agent conversations table
CREATE TABLE IF NOT EXISTS agent_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id TEXT NOT NULL,
    user_id TEXT DEFAULT 'system',
    messages JSONB NOT NULL DEFAULT '[]',
    summary TEXT,
    summary_embedding vector(1536),
    started_at TIMESTAMPTZ DEFAULT NOW(),
    ended_at TIMESTAMPTZ,
    metadata JSONB DEFAULT '{}'
);

-- Index for conversation search
CREATE INDEX IF NOT EXISTS agent_conversations_summary_embedding_idx ON agent_conversations 
USING ivfflat (summary_embedding vector_cosine_ops)
WITH (lists = 100);

-- Agent knowledge graph
CREATE TABLE IF NOT EXISTS agent_knowledge_graph (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    confidence FLOAT DEFAULT 1.0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(subject, predicate, object, agent_id)
);

-- Agent expertise tracking
CREATE TABLE IF NOT EXISTS agent_expertise (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id TEXT NOT NULL,
    skill TEXT NOT NULL,
    proficiency FLOAT DEFAULT 0.5,
    successful_tasks INTEGER DEFAULT 0,
    failed_tasks INTEGER DEFAULT 0,
    last_used TIMESTAMPTZ DEFAULT NOW(),
    metadata JSONB DEFAULT '{}',
    UNIQUE(agent_id, skill)
);

-- Function to update access timestamp
CREATE OR REPLACE FUNCTION update_accessed_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.accessed_at = NOW();
    NEW.access_count = OLD.access_count + 1;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update access info on memory retrieval
CREATE TRIGGER update_memory_accessed
BEFORE UPDATE ON agent_memories
FOR EACH ROW
EXECUTE FUNCTION update_accessed_at();

-- View for most relevant memories
CREATE OR REPLACE VIEW relevant_memories AS
SELECT 
    am.*,
    (0.7 * am.importance + 0.3 * (1.0 / (EXTRACT(EPOCH FROM (NOW() - am.accessed_at)) / 3600 + 1))) as relevance_score
FROM agent_memories am
ORDER BY relevance_score DESC;