
CREATE OR REPLACE FUNCTION match_memories(
    query_embedding vector(1536),
    match_threshold float,
    match_count int,
    filter_agent_id text DEFAULT NULL,
    filter_type text DEFAULT NULL
)
RETURNS TABLE (
    id uuid,
    agent_id text,
    content text,
    memory_type text,
    metadata jsonb,
    similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        am.id,
        am.agent_id,
        am.content,
        am.memory_type,
        am.metadata,
        1 - (am.embedding <=> query_embedding) as similarity
    FROM agent_memories am
    WHERE 
        (filter_agent_id IS NULL OR am.agent_id = filter_agent_id)
        AND (filter_type IS NULL OR am.memory_type = filter_type)
        AND 1 - (am.embedding <=> query_embedding) > match_threshold
    ORDER BY am.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;